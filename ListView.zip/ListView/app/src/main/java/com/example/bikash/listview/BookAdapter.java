package com.example.bikash.listview;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class BookAdapter extends ArrayAdapter<Book> {

    private Context context;
    private ArrayList<Book>bookArrayList;

    public BookAdapter(Context context,ArrayList<Book>bookArrayList)
    {
        super(context,R.layout.single_row,bookArrayList);
        this.context=context;
        this.bookArrayList=bookArrayList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView=inflater.inflate(R.layout.single_row,parent,false);
        ImageView imageView=convertView.findViewById(R.id.bookIV);
        TextView bookName=convertView.findViewById(R.id.bookNameTV);
        TextView authorName=convertView.findViewById(R.id.authorNameTV);

        imageView.setImageResource(bookArrayList.get(position).getBookImage());
        bookName.setText(bookArrayList.get(position).getBookName());
        authorName.setText(bookArrayList.get(position).getAuthorName());
        return convertView;
    }
}
