package com.example.bikash.listview;

public class Book {
    private int bookImage;
    private String bookName,authorName;

    public Book(int bookImage, String bookName, String authorName) {
        this.bookImage = bookImage;
        this.bookName = bookName;
        this.authorName = authorName;
    }

    public int getBookImage() {
        return bookImage;
    }

    public void setBookImage(int bookImage) {
        this.bookImage = bookImage;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }
}
