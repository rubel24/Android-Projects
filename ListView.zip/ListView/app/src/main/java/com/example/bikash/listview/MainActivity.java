package com.example.bikash.listview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView bookList;
    ArrayList<String>books;
    BookAdapter adapter;
    ArrayList<Book>bookArrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bookList=findViewById(R.id.bookLV);
        bookArrayList=new ArrayList<>();

        bookArrayList.add(new Book(R.mipmap.ic_launcher,"Java","Ezhar"));
        bookArrayList.add(new Book(R.mipmap.ic_launcher,"Python","A"));
        bookArrayList.add(new Book(R.mipmap.ic_launcher,"C++","B"));
        bookArrayList.add(new Book(R.mipmap.ic_launcher,"Android","C"));
        bookArrayList.add(new Book(R.mipmap.ic_launcher,"HTML","D"));
        bookArrayList.add(new Book(R.mipmap.ic_launcher,"HTML","D"));
        bookArrayList.add(new Book(R.mipmap.ic_launcher,"HTML","D"));
        bookArrayList.add(new Book(R.mipmap.ic_launcher,"HTML","D"));
        bookArrayList.add(new Book(R.mipmap.ic_launcher,"HTML","D"));
        bookArrayList.add(new Book(R.mipmap.ic_launcher,"HTML","D"));
        bookArrayList.add(new Book(R.mipmap.ic_launcher,"HTML","D"));
        bookArrayList.add(new Book(R.mipmap.ic_launcher,"HTML","D"));
        bookArrayList.add(new Book(R.mipmap.ic_launcher,"HTML","D"));
        bookArrayList.add(new Book(R.mipmap.ic_launcher,"HTML","D"));
        bookArrayList.add(new Book(R.mipmap.ic_launcher,"HTML","D"));
        adapter=new BookAdapter(this,bookArrayList);
        bookList.setAdapter(adapter);

        bookList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this,bookArrayList.get(position).getBookName(),Toast.LENGTH_SHORT);
            }
        });
    }
}
